#!/usr/bin/env python



#
#
# import exifread
# Open image file for reading (binary mode)
# f = open(path_name, 'rb')

# Return Exif tags
# tags = exifread.process_file(f)
#
# tags is a dictionary.
#
#
# tags['EXIF DateTimeOriginal'] --> datetimeofcapture.
#
#



# import modules used here -- sys is a very standard one
import os, os.path, shutil, sys, commands, exifread



def convert(datetimestring):
    
    return 'IMG_' + datetimestring.replace(':','').replace(' ','_') + '.jpg'

    

# Gather our code in a main() function
def main():
    print 'Start....................',
    
    index = 0
    filenames = os.listdir('../camera/ipodcopy')
    length = len(filenames)


   # sys.exit(1)
    while(index < length):

	f = open('../camera/ipodcopy/'+filenames[index],'rb')
	tags = exifread.process_file(f)
	cmd = 'mv ../camera/ipodcopy/' + filenames[index] + ' ./test2/' + convert(str(tags['EXIF DateTimeOriginal']))
        
	index += 1

        (status, output) = commands.getstatusoutput(cmd)
        if status:
            sys.stderr.write(output)
	    sys.exit(1)
	
    print '....DONE'

	
        
    
# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
    main()
