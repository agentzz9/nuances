#!/usr/bin/env python

# import modules used here -- sys is a very standard one
import os, os.path, shutil, sys, commands

# Gather our code in a main() function
def main():
    print 'Start....................',
    
    index = 0
    filenames = os.listdir('./images')
    length = len(filenames)

    while(index < length):
        cmd = 'mv ./images/' + filenames[index] + ' ./finalimages/' + str(index) + sys.argv[1]
        index += 1

        (status, output) = commands.getstatusoutput(cmd)
        if status:
            sys.stderr.write(output)
	    sys.exit(1)
 
    
    print '....DONE'

	
        
    
# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
    main()
