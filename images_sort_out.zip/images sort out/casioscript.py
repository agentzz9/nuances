#!/usr/bin/env python

# str(datetime.datetime(1995,2,2,0,0,0))



# import modules used here -- sys is a very standard one
import os, os.path, shutil, sys, commands, exifread


# Gather our code in a main() function
def main():
  
  foldernames = os.listdir('../camera/casiocopy')
  
  for foldername in foldernames:
    filenames = os.listdir('../camera/casiocopy/' + foldername)
    filenames = sorted(filenames)
    count = 250000
    for filename in filenames:
      name = 'IMG_' + foldername + '_' + str(count) + '.jpg'
      count += 1
      cmd = 'mv ../camera/casiocopy/' + foldername + '/' + filename + ' ' + '../camera/casiocopy/'+ foldername + '/' + name
      print cmd
      
      (status, output) = commands.getstatusoutput(cmd)
      if status:
        sys.stderr.write(output)
        sys.exit(1)
    
      
      
# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
  main()
